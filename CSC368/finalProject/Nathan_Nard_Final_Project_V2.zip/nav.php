<!--------------------------------
# Nathan Nard
# nnard2
# CSC 368 - Final Project
# May 6, 2018
--------------------------------->
<br>
<br>
<a href="index.php"         > Welcome Page      </a><br>
<a href="add_stock.php"     > Add Stock Item      </a><br>
<a href="edit_start.php"    > Edit Stock Item     </a><br>
<a href="view_inventory.php"> View Whole Inventory</a><br>