<!--------------------------------
# Nathan Nard
# nnard2
# CSC 368 - Final Project
# May 6, 2018
--------------------------------->
<?php
    ini_set("display_errors","1");
    error_reporting(E_ALL);

    $host='127.0.0.1';
    $user='nnard2';
    $pass='qwerty123456';
    $db='nnard2';

    $connection = mysqli_connect($host, $user, $pass, $db);
?>
