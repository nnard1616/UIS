<!--------------------------------
# Nathan Nard
# nnard2
# CSC 368 - Final Project
# May 6, 2018
--------------------------------->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Grocery Store Inventory</title>
    </head>
    <h1>Welcome</h1>
    <body>
        <h2>This is an application for managing inventory of Generic Grocery Store.</h2>
        <?php require('nav.php');?>
    </body>
</html>
