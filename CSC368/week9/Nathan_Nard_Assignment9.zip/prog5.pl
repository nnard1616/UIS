#!/usr/bin/perl
#------------------------------
# Nathan Nard 
# nnard2
# CSC 368 - Assignment 9
# March 24, 2018
#------------------------------

print "First number: ";
chomp($n1 = <STDIN>);
print "Second number: ";
chomp($n2 = <STDIN>);

print "The product of the two numbers is: " . $n1 * $n2 . "\n";
